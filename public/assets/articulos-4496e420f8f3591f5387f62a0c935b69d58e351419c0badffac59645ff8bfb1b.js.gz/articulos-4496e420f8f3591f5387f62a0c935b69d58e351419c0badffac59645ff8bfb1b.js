
function stopRKey(evt) {
   var evt = (evt) ? evt : ((event) ? event : null);
   var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
   if ((evt.keyCode == 13) && (node.type=="text" || node.type=="number")) {return false;}
}

document.onkeypress = stopRKey; 

$(document).ready(function() {

    

});

  
